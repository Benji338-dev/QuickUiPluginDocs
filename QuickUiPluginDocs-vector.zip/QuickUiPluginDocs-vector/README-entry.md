## Entry to add to README.md

Add this line in the "Main" components list, next to Tween, Auto-Scale, Auto-Script, Assets, One-TopBar and Texture,
and use the same list syntax as the neighbouring entries:

- [Vector Creator](docs/MainPlugin/Vector.md)

## Existing link problem noticed

In the "More Tools" list, Convert, Preset, Zoom, Rotate, Center and Settings all point to `docs/components/images.md`,
and the "More Tools" entry itself points to `docs/components/text.md`. These probably need their own pages or correct targets.
